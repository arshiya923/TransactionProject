﻿using Microsoft.AspNetCore.Mvc;
using TransactionProject.Database;
using TransactionProject.Models;

namespace TransactionProject.Controllers
{
    public class TransactionHandlerController : Controller
    {
        private readonly TransactionDBContext _dbContext;
        public TransactionHandlerController(TransactionDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<IActionResult> Index()
        {
            List<Transaction> transactions = _dbContext.Transactions.ToList();
            ViewBag.TransactionPages = 10;
            return View(transactions);
        }
        [HttpPost]
        public async Task<IActionResult> Index(DateTime TransactionFrom, DateTime TransactionTo, string TranasctionType)
        {
            List<Transaction> transactions = _dbContext.Transactions.ToList();


            return View(transactions);
        }
    }
}
