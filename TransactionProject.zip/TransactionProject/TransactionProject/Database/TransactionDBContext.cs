﻿using Microsoft.EntityFrameworkCore;
using TransactionProject.Models;

namespace TransactionProject.Database
{
    public class TransactionDBContext : DbContext
    {
        public TransactionDBContext(DbContextOptions<TransactionDBContext> dbContextOptions) : base(dbContextOptions) {}

        public DbSet<Transaction> Transactions { get; set; }
    }
}
