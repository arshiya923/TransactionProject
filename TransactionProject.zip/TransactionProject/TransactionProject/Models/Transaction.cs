﻿namespace TransactionProject.Models
{
    public class Transaction
    {
        public int id { get; set; }
        public DateTime FinancialDate { get; set; }
        public DateTime FinancialDateShamsi { get; set; }
        public DateTime CheckoutDate { get; set; }
        public DateTime CheckoutDateShamsi { get; set; }
        public DateTime TransactionDate { get; set; }
        public string TransactionTime { get; set; }
        public DateTime TransactionDateShamsi { get; set; }
        public string CardNumber { get; set; }
        public string TerminalNumber { get; set; }
        public string TransactionSerial { get; set; }
        public string TrackCode { get; set; }
        public string SourceCode { get; set; }
        public double MainAmount { get; set; }
        public double PayAmount { get; set; }
        public string TransactionType { get; set; }
        public string TransactionStatus { get; set; }
        public string SwitchCode { get; set; }
        public string AutomateCharchOperator { get; set; }
        public string TerminalName { get; set; }
        public string TransactionTypeCode { get; set; }
        public string Description { get; set; }
        public string ReceiverNationalId { get; set; }
        public string CustomerNumber { get; set; }
    }
}
